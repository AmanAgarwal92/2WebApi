﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TheTwoApis.Models;

namespace TheTwoApis.Controllers
{
    [RoutePrefix("api/Values")]
    public class ValuesController : ApiController
    {
        //Creating the reference of the DB Context Class
        ItemDetailsEntities1 ide;

        //Using Dependency Injection via Constructor to inject object at run time
        public ValuesController() {
            this.ide = new ItemDetailsEntities1();
        }

        //Retrieving all the matching records based on the ItemName
        [HttpGet]
        [Route("ItemsByName/{ItemName}")]
        public IHttpActionResult ItemsBy(string ItemName)
        {
            if (ItemName.Length < 3 || ItemName.Length > 12)
            {
                return Json(new { status = "fail", message = "Item name should be between 3 to 12 characters" });
            }

            var items = (from ep in ide.Categories
                         join e in ide.SubCategories on ep.ID equals e.CateogoryID
                         join t in ide.Items on e.SubID equals t.SubCateogoryID
                         where t.SCName == ItemName
                         select new
                         {
                             CategoryID = ep.ID,
                             CategoryIDName = ep.Name,
                             SubCategoryID = e.SubID,
                             SubCategoryName = e.CName,
                             ItemId = t.ItemID,
                             ItemName = t.SCName,
                             ItemDescription = t.SCDescription

                         }

                ).ToList();

            if (items == null || items.Count == 0)
            {
                return Json(new { status = "fail", message = "No entity with that type/id was found" });
            }
            return Ok(items);
        }

        //Retrieving all the records based
        [HttpGet]
        [Route("ItemsByName")]
        public IHttpActionResult ItemsByName()
        {
            var items = (from ep in ide.Categories
                         join e in ide.SubCategories on ep.ID equals e.CateogoryID
                         join t in ide.Items on e.SubID equals t.SubCateogoryID
                         select new
                         {
                             CategoryID = ep.ID,
                             CategoryIDName = ep.Name,
                             SubCategoryID = e.SubID,
                             SubCategoryName = e.CName,
                             ItemId = t.ItemID,
                             ItemName = t.SCName,
                             ItemDescription = t.SCDescription

                         }

                ).ToList();
            return Ok(items);
        }

        [HttpDelete]
        [Route("DeleteByCategory/{CategoryID}")]
        public IHttpActionResult DeleteByCategory(int CategoryID)
        {
            if (CategoryID <= 0)
                return BadRequest("Not a valid id");

            var category = ide.Categories.Where(temp => temp.ID == CategoryID).FirstOrDefault();
            var subCategory = ide.SubCategories.Where(temp => temp.CateogoryID == category.ID).ToList();

            foreach (var sbc in subCategory) {
                var item = ide.Items.Where(temp => temp.SubCateogoryID == sbc.SubID).ToList();
                foreach (var item1 in item) {
                    ide.Entry(item1).State = System.Data.Entity.EntityState.Deleted;
                }

                ide.Entry(sbc).State = System.Data.Entity.EntityState.Deleted;
            }
            ide.Entry(category).State = System.Data.Entity.EntityState.Deleted;
            ide.SaveChanges();

            return Ok();
        }





    }
}
